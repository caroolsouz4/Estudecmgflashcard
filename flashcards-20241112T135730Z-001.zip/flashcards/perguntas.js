criaCartao(
    'Filosofia',
    'De quem é a famosa frase penso, logo existo?',
    'A famosa frase penso, logo existo foi dita por Descartes'
)

criaCartao(
    'Geografia',
    'Em qual continente está localizada a Austrália?',
    'A Austrália está localizada na Oceania'
)

criaCartao(
    'Lingua Portuguesa',
    'Qual a diferença entre mas, mais e más?',
    'Mas é porém, mais é quantidade e más é mau, por exemplo: gostei, mas não vou levar; hoje tem mais pessoas aqui que ontem; as pessoas são más'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz ela mora com ele em Inglês?',
    'Ela mora com ele em ingles é she lives with him ( XI LIVIS UIFI RIM )'
)